# معماری gnss-core

## نمای کلی

```
Application
    ↓
High-Level API (gnss.h)
    ↓
Normalized Data Model (gnss_solution_t + Field Registry)
    ↓
Message Dispatcher
    ↓
Protocol Parsers (NMEA / UBX / Vendor)
    ↓
Frame Parser (Byte Stream + Protocol Detection)
    ↓
User Buffer / UART / DMA / SPI / File
```

## اصول طراحی

1. **Zero Dynamic Allocation** — تمام بافرها و ساختارها static یا caller-owned هستند.
2. **Protocol-Centric** — یک پارسر NMEA و یک پارسر UBX برای اکثر receiverها کافی است.
3. **Compile-Time Configuration** — هر قابلیتی که استفاده نشود، در firmware وارد نمی‌شود.
4. **Deterministic** — رفتار قابل پیش‌بینی، بدون malloc، بدون recursion.

## مدل داده

- **Canonical Units**:
  - مختصات → درجه اعشاری
  - ارتفاع → متر
  - سرعت → متر بر ثانیه
  - جهت → درجه

- **gnss_solution_t** — ساختار اصلی حاوی موقعیت، سرعت، فیکس و DOP

## پارسر فریم (Frame Parser)

- State Machine سبک
- تشخیص پروتکل از اولین بایت:
  - `$` → NMEA
  - `0xB5 0x62` → UBX
- مناسب برای UART Interrupt و DMA

## NMEA Parser

- پشتیبانی از Talker ID مختلف (GP, GN, GA, GL, GB)
- Validation کامل checksum
- تبدیل مختصات `ddmm.mmmm` به درجه اعشاری
- **GSV Aggregation** — پشتیبانی از پیام‌های چندبخشی

## UBX Parser

- Framing + Fletcher checksum
- پشتیبانی اولیه از `NAV-PVT`
- قابلیت گسترش برای پیام‌های دیگر

## گسترش‌پذیری

کاربر می‌تواند پروتکل اختصاصی خود را با `gnss_register_protocol()` اضافه کند (در نسخه‌های آینده).

## مصرف حافظه (تقریبی)

| پیکربندی              | Flash     | RAM      |
|-----------------------|-----------|----------|
| Minimal (فقط GGA)     | ~4 KB     | ~150 B   |
| Standard (NMEA+UBX)   | ~14 KB    | ~1.1 KB  |
| Full + GSV            | ~18 KB    | ~1.8 KB  |

## نتیجه‌گیری

این معماری تعادل عالی بین **سادگی استفاده**، **عملکرد بالا** و **قابلیت گسترش** ایجاد کرده است.
