# gnss-core

کتابخانه حرفه‌ای، سبک و production-grade برای **Parsing و استخراج داده GNSS/GPS** در سیستم‌های Embedded.

## ویژگی‌های کلیدی

- **بدون تخصیص پویا** در هسته (Zero Dynamic Allocation)
- **دو حالت ورودی**: بافر کامل + بایت به بایت (مناسب UART/DMA)
- **تشخیص خودکار پروتکل** (NMEA / UBX)
- **پشتیبانی از NMEA** با Talker ID مختلف (GP, GN, GA, GL, ...)
- **پشتیبانی اولیه از UBX** (NAV-PVT)
- **API بسیار ساده** + API پیشرفته
- **قابل تنظیم کامل** در زمان کامپایل
- **مناسب STM32** و سایر MCUها (C99)

## ساختار پروژه

```
gnss/
├── include/           ← هدرهای عمومی
├── src/
│   ├── core/
│   └── parser/        ← NMEA + UBX + Frame
├── examples/
└── docs/
```

## استفاده سریع (سطح ۱)

```c
#include "gnss.h"

uint8_t rx_buf[256];

void main(void)
{
    gnss_init();

    // روش ۱: بافر کامل
    gnss_parse(rx_buf, sizeof(rx_buf));

    // روش ۲: بایت به بایت (مناسب ISR/DMA)
    for(int i=0; i<received; i++)
        gnss_feed_byte(rx_buf[i]);

    if (gnss_has_new_solution()) {
        gnss_solution_t sol;
        if (gnss_get_solution(&sol) == GNSS_OK) {
            // sol.latitude_deg ...
        }
    }
}
```

## پیکربندی (gnss_config.h)

```c
#define GNSS_ENABLE_NMEA          1
#define GNSS_ENABLE_UBX           1
#define GNSS_ENABLE_GGA           1
#define GNSS_ENABLE_GSV           1
#define GNSS_MAX_SATELLITES       32
#define GNSS_USE_DOUBLE           1
```

## وضعیت فعلی پیاده‌سازی

- [x] هسته اصلی + Dispatcher
- [x] پارسر فریم (Byte Stream)
- [x] پارسر NMEA (GGA, RMC, GSV پایه)
- [x] پارسر UBX (NAV-PVT پایه)
- [ ] تست کامل
- [ ] مثال STM32
- [ ] مستندات کامل

## مجوز

MIT License

---

**gnss-core** — GNSS Parsing Engine برای Embedded Systems
```

حالا پروژه تا این مرحله کامل و قابل کامپایل است. 

**آیا می‌خواهید مرحله بعدی (تست‌ها + مثال ساده + مستندات بیشتر) را ادامه دهم؟**