// gnss/src/core/gnss.c
// هسته اصلی کتابخانه gnss-core
// پیاده‌سازی API سطح ۱ و ۲ + Dispatcher

#include "gnss.h"
#include "gnss_config.h"
#include "../parser/frame.h"
#include <string.h>
#include <stdbool.h>

#if GNSS_ENABLE_STATS
static gnss_stats_t g_stats = {0};
#endif

static gnss_solution_t g_solution = {0};
static bool g_has_new_solution = false;

#if GNSS_ENABLE_GSV
static gnss_satellite_t g_satellites[GNSS_MAX_SATELLITES];
static uint8_t g_sat_count = 0;
#endif

// ======================== مقداردهی اولیه ========================
void gnss_init(void)
{
    memset(&g_solution, 0, sizeof(g_solution));
    g_has_new_solution = false;

#if GNSS_ENABLE_GSV
    memset(g_satellites, 0, sizeof(g_satellites));
    g_sat_count = 0;
#endif

#if GNSS_ENABLE_STATS
    gnss_reset_stats();
#endif

    // مقداردهی اولیه پارسر فریم
    gnss_frame_init();
}

// ======================== توابع کمکی داخلی ========================
static void gnss_update_solution(const gnss_solution_t* new_sol)
{
    // کپی امن (بدون تخصیص پویا)
    memcpy(&g_solution, new_sol, sizeof(gnss_solution_t));
    g_has_new_solution = true;

#if GNSS_ENABLE_STATS
    g_stats.messages_parsed++;
#endif

#if GNSS_ENABLE_CALLBACKS
    extern void gnss_internal_fire_callback(gnss_event_type_t, const void*, uint8_t);
    gnss_internal_fire_callback(GNSS_EVENT_SOLUTION, &g_solution, 0);
#endif
}

// ======================== API سطح ۱ ========================
gnss_error_t gnss_parse(const uint8_t* buffer, size_t length)
{
    if (!buffer || length == 0) {
        return GNSS_ERR_INVALID_ARG;
    }

#if GNSS_ENABLE_STATS
    g_stats.messages_received++;
#endif

    return gnss_frame_parse_buffer(buffer, length);
}

gnss_error_t gnss_feed(const uint8_t* data, size_t length)
{
    if (!data || length == 0) {
        return GNSS_ERR_INVALID_ARG;
    }

    gnss_error_t err = GNSS_OK;
    for (size_t i = 0; i < length; i++) {
        err = gnss_feed_byte(data[i]);
        if (err != GNSS_OK && err != GNSS_ERR_UNSUPPORTED_MESSAGE) {
            return err;
        }
    }
    return GNSS_OK;
}

gnss_error_t gnss_feed_byte(uint8_t byte)
{
#if GNSS_ENABLE_STATS
    // آمار بایت‌ها در صورت نیاز
#endif
    return gnss_frame_feed_byte(byte);
}

bool gnss_has_new_solution(void)
{
    return g_has_new_solution;
}

gnss_error_t gnss_get_solution(gnss_solution_t* solution)
{
    if (!solution) {
        return GNSS_ERR_INVALID_ARG;
    }
    if (!g_has_new_solution) {
        return GNSS_ERR_NO_FIX;
    }

    memcpy(solution, &g_solution, sizeof(gnss_solution_t));
    g_has_new_solution = false;   // مصرف شد
    return GNSS_OK;
}

// ======================== API سطح ۲ ========================
gnss_error_t gnss_get_field(gnss_field_id_t field, void* value, size_t* size)
{
    if (!value || !size) {
        return GNSS_ERR_INVALID_ARG;
    }

    switch (field) {
        case GNSS_FIELD_LATITUDE:
            if (*size < sizeof(gnss_float_t)) return GNSS_ERR_INVALID_ARG;
            *(gnss_float_t*)value = g_solution.latitude_deg;
            *size = sizeof(gnss_float_t);
            return g_solution.valid_position ? GNSS_OK : GNSS_ERR_NO_FIX;

        case GNSS_FIELD_LONGITUDE:
            if (*size < sizeof(gnss_float_t)) return GNSS_ERR_INVALID_ARG;
            *(gnss_float_t*)value = g_solution.longitude_deg;
            *size = sizeof(gnss_float_t);
            return g_solution.valid_position ? GNSS_OK : GNSS_ERR_NO_FIX;

        case GNSS_FIELD_ALTITUDE:
            if (*size < sizeof(gnss_float_t)) return GNSS_ERR_INVALID_ARG;
            *(gnss_float_t*)value = g_solution.altitude_m;
            *size = sizeof(gnss_float_t);
            return g_solution.valid_position ? GNSS_OK : GNSS_ERR_NO_FIX;

        case GNSS_FIELD_SPEED:
            if (*size < sizeof(gnss_float_t)) return GNSS_ERR_INVALID_ARG;
            *(gnss_float_t*)value = g_solution.speed_mps;
            *size = sizeof(gnss_float_t);
            return g_solution.valid_velocity ? GNSS_OK : GNSS_ERR_NO_FIX;

        case GNSS_FIELD_SATELLITES:
            if (*size < sizeof(uint8_t)) return GNSS_ERR_INVALID_ARG;
            *(uint8_t*)value = g_solution.satellites;
            *size = sizeof(uint8_t);
            return GNSS_OK;

        case GNSS_FIELD_HDOP:
            if (*size < sizeof(gnss_float_t)) return GNSS_ERR_INVALID_ARG;
            *(gnss_float_t*)value = g_solution.hdop;
            *size = sizeof(gnss_float_t);
            return GNSS_OK;

        default:
            return GNSS_ERR_INVALID_FIELD;
    }
}

bool gnss_is_valid(gnss_field_id_t field)
{
    switch (field) {
        case GNSS_FIELD_LATITUDE:
        case GNSS_FIELD_LONGITUDE:
        case GNSS_FIELD_ALTITUDE:
            return g_solution.valid_position;
        case GNSS_FIELD_SPEED:
        case GNSS_FIELD_COURSE:
            return g_solution.valid_velocity;
        default:
            return true;
    }
}

// ======================== GSV ========================
#if GNSS_ENABLE_GSV
gnss_error_t gnss_get_satellite_count(uint8_t* count)
{
    if (!count) return GNSS_ERR_INVALID_ARG;
    *count = g_sat_count;
    return GNSS_OK;
}

gnss_error_t gnss_get_satellite(uint8_t index, gnss_satellite_t* sat)
{
    if (!sat || index >= g_sat_count) {
        return GNSS_ERR_INVALID_ARG;
    }
    memcpy(sat, &g_satellites[index], sizeof(gnss_satellite_t));
    return GNSS_OK;
}
#endif

// ======================== آمار ========================
#if GNSS_ENABLE_STATS
gnss_error_t gnss_get_stats(gnss_stats_t* stats)
{
    if (!stats) return GNSS_ERR_INVALID_ARG;
    memcpy(stats, &g_stats, sizeof(gnss_stats_t));
    return GNSS_OK;
}

void gnss_reset_stats(void)
{
    memset(&g_stats, 0, sizeof(g_stats));
}
#endif

// ======================== توابع داخلی Dispatcher (فراخوانی از پارسر) ========================
// این توابع توسط پارسرهای NMEA و UBX فراخوانی می‌شوند
void gnss_internal_update_solution(const gnss_solution_t* sol)
{
    gnss_update_solution(sol);
}

#if GNSS_ENABLE_GSV
void gnss_internal_set_satellites(const gnss_satellite_t* sats, uint8_t count)
{
    if (count > GNSS_MAX_SATELLITES) count = GNSS_MAX_SATELLITES;
    memcpy(g_satellites, sats, count * sizeof(gnss_satellite_t));
    g_sat_count = count;

#if GNSS_ENABLE_CALLBACKS
    extern void gnss_internal_fire_callback(gnss_event_type_t, const void*, uint8_t);
    gnss_internal_fire_callback(GNSS_EVENT_SATELLITES, g_satellites, count);
#endif
}
#endif

// تابع گزارش خطا (قابل گسترش با callback)
void gnss_internal_report_error(gnss_error_t err)
{
#if GNSS_ENABLE_STATS
    if (err == GNSS_ERR_BAD_CHECKSUM) g_stats.checksum_errors++;
    else if (err == GNSS_ERR_INVALID_FRAME) g_stats.frame_errors++;
#endif
}
