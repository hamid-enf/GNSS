// gnss/src/parser/nmea/nmea_parser.c
// پارسر NMEA 0183 - نسخه کامل با GSV aggregation

#include "nmea_parser.h"
#include "gnss_config.h"
#include "../core/gnss.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#if GNSS_ENABLE_NMEA

// ======================== وضعیت GSV aggregation ========================
#if GNSS_ENABLE_GSV
static gnss_satellite_t g_gsv_buffer[GNSS_MAX_SATELLITES];
static uint8_t g_gsv_count = 0;
static uint8_t g_gsv_expected_msgs = 0;
static uint8_t g_gsv_current_msg = 0;
#endif

// ======================== توابع کمکی ========================
static uint8_t nmea_checksum(const uint8_t* data, size_t len)
{
    uint8_t checksum = 0;
    for (size_t i = 1; i < len; i++) {
        if (data[i] == '*') break;
        checksum ^= data[i];
    }
    return checksum;
}

static bool nmea_validate_checksum(const uint8_t* buffer, size_t len)
{
    if (len < 5 || buffer[len-5] != '*') return false;

    uint8_t calc = nmea_checksum(buffer, len);
    char hex[3] = { buffer[len-4], buffer[len-3], '\0' };
    uint8_t recv = (uint8_t)strtoul(hex, NULL, 16);
    return calc == recv;
}

static gnss_float_t nmea_ddmm_to_deg(const char* field, char hemisphere)
{
    if (!field || field[0] == '\0') return 0.0;
    double val = atof(field);
    int degrees = (int)(val / 100);
    double minutes = val - (degrees * 100);
    double result = degrees + (minutes / 60.0);
    if (hemisphere == 'S' || hemisphere == 'W') result = -result;
    return (gnss_float_t)result;
}

// ======================== GGA ========================
#if GNSS_ENABLE_GGA
static gnss_error_t parse_gga(const uint8_t* fields[], int field_count)
{
    if (field_count < 10) return GNSS_ERR_INVALID_FRAME;

    gnss_solution_t sol = {0};
    sol.latitude_deg  = nmea_ddmm_to_deg((const char*)fields[2], fields[3][0]);
    sol.longitude_deg = nmea_ddmm_to_deg((const char*)fields[4], fields[5][0]);
    sol.fix_type = (uint8_t)atoi((const char*)fields[6]);
    sol.valid_position = (sol.fix_type > 0);
    sol.satellites = (uint8_t)atoi((const char*)fields[7]);
    sol.hdop = (gnss_float_t)atof((const char*)fields[8]);
    sol.altitude_m = (gnss_float_t)atof((const char*)fields[9]);
    sol.valid_time = true;

    gnss_internal_update_solution(&sol);
    return GNSS_OK;
}
#endif

// ======================== RMC ========================
#if GNSS_ENABLE_RMC
static gnss_error_t parse_rmc(const uint8_t* fields[], int field_count)
{
    if (field_count < 8) return GNSS_ERR_INVALID_FRAME;

    gnss_solution_t sol = {0};
    char status = fields[2][0];
    sol.valid_position = (status == 'A');
    sol.valid_velocity = (status == 'A');

    sol.latitude_deg  = nmea_ddmm_to_deg((const char*)fields[3], fields[4][0]);
    sol.longitude_deg = nmea_ddmm_to_deg((const char*)fields[5], fields[6][0]);
    sol.speed_mps = (gnss_float_t)(atof((const char*)fields[7]) * 0.514444);
    if (field_count > 8) sol.course_deg = (gnss_float_t)atof((const char*)fields[8]);

    gnss_internal_update_solution(&sol);
    return GNSS_OK;
}
#endif

// ======================== GSV با Aggregation کامل ========================
#if GNSS_ENABLE_GSV
static gnss_error_t parse_gsv(const uint8_t* fields[], int field_count)
{
    if (field_count < 4) return GNSS_ERR_INVALID_FRAME;

    uint8_t total_msgs   = (uint8_t)atoi((const char*)fields[1]);
    uint8_t msg_num      = (uint8_t)atoi((const char*)fields[2]);
    uint8_t sats_in_view = (uint8_t)atoi((const char*)fields[3]);

    if (msg_num == 1) {
        // شروع پیام جدید
        g_gsv_count = 0;
        g_gsv_expected_msgs = total_msgs;
        g_gsv_current_msg = 1;
    }

    // پردازش ماهواره‌ها (هر ۴ فیلد یک ماهواره)
    int sat_index = 4;
    while (sat_index + 3 < field_count && g_gsv_count < GNSS_MAX_SATELLITES) {
        gnss_satellite_t sat = {0};
        sat.prn = (uint8_t)atoi((const char*)fields[sat_index]);
        sat.elevation = (uint8_t)atoi((const char*)fields[sat_index+1]);
        sat.azimuth   = (uint16_t)atoi((const char*)fields[sat_index+2]);
        sat.snr       = (uint8_t)atoi((const char*)fields[sat_index+3]);
        sat.gnss_id   = 0; // TODO: استخراج از Talker ID
        sat.used_in_solution = false;

        g_gsv_buffer[g_gsv_count++] = sat;
        sat_index += 4;
    }

    if (msg_num == g_gsv_expected_msgs) {
        // تمام پیام‌ها دریافت شد
        gnss_internal_set_satellites(g_gsv_buffer, g_gsv_count);
    }

    return GNSS_OK;
}
#endif

// ======================== تابع اصلی ========================
gnss_error_t nmea_parse(const uint8_t* buffer, size_t length)
{
    if (length < 6 || buffer[0] != '$' || buffer[length-2] != '\r') {
        return GNSS_ERR_INVALID_FRAME;
    }
    if (!nmea_validate_checksum(buffer, length)) {
        return GNSS_ERR_BAD_CHECKSUM;
    }

    uint8_t* fields[20] = {0};
    int field_count = 0;
    uint8_t* start = (uint8_t*)buffer + 1;

    for (size_t i = 1; i < length && field_count < 19; i++) {
        if (buffer[i] == ',' || buffer[i] == '*') {
            fields[field_count++] = start;
            start = (uint8_t*)&buffer[i + 1];
            if (buffer[i] == '*') break;
        }
    }

    if (field_count < 1) return GNSS_ERR_INVALID_FRAME;

    const char* msg_id = (const char*)fields[0] + 2; // بعد از Talker ID

#if GNSS_ENABLE_GGA
    if (strncmp(msg_id, "GGA", 3) == 0) return parse_gga((const uint8_t**)fields, field_count);
#endif
#if GNSS_ENABLE_RMC
    if (strncmp(msg_id, "RMC", 3) == 0) return parse_rmc((const uint8_t**)fields, field_count);
#endif
#if GNSS_ENABLE_GSV
    if (strncmp(msg_id, "GSV", 3) == 0) return parse_gsv((const uint8_t**)fields, field_count);
#endif

// ======================== GSA ========================
#if GNSS_ENABLE_GSA
static gnss_error_t parse_gsa(const uint8_t* fields[], int field_count)
{
    if (field_count < 4) return GNSS_ERR_INVALID_FRAME;

    gnss_solution_t sol = {0};
    // fix type: 1=None, 2=2D, 3=3D
    int fix = atoi((const char*)fields[2]);
    sol.fix_type = (fix >= 2) ? fix : 0;
    sol.valid_position = (fix >= 2);

    // PDOP, HDOP, VDOP
    if (field_count > 15) {
        sol.pdop = (gnss_float_t)atof((const char*)fields[15]);
        sol.hdop = (gnss_float_t)atof((const char*)fields[16]);
        sol.vdop = (gnss_float_t)atof((const char*)fields[17]);
    }

    gnss_internal_update_solution(&sol);
    return GNSS_OK;
}
#endif

// ======================== VTG ========================
#if GNSS_ENABLE_VTG
static gnss_error_t parse_vtg(const uint8_t* fields[], int field_count)
{
    if (field_count < 5) return GNSS_ERR_INVALID_FRAME;

    gnss_solution_t sol = {0};
    sol.course_deg = (gnss_float_t)atof((const char*)fields[1]);
    sol.speed_mps  = (gnss_float_t)(atof((const char*)fields[5]) * 0.514444); // knots → m/s
    sol.valid_velocity = true;

    gnss_internal_update_solution(&sol);
    return GNSS_OK;
}
#endif

#if GNSS_ENABLE_GSA
    if (strncmp(msg_id, "GSA", 3) == 0) return parse_gsa((const uint8_t**)fields, field_count);
#endif
#if GNSS_ENABLE_VTG
    if (strncmp(msg_id, "VTG", 3) == 0) return parse_vtg((const uint8_t**)fields, field_count);
#endif

    return GNSS_ERR_UNSUPPORTED_MESSAGE;
}

#endif // GNSS_ENABLE_NMEA
