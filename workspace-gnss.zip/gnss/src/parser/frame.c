// gnss/src/parser/frame.c
// پارسر فریم سبک و بدون تخصیص پویا
// تشخیص پروتکل: NMEA ($) و UBX (0xB5 0x62)

#include "frame.h"
#include "../core/gnss.h"
#include "gnss_config.h"
#include <string.h>

#if GNSS_ENABLE_NMEA
#include "nmea/nmea_parser.h"
#endif
#if GNSS_ENABLE_UBX
#include "ubx/ubx_parser.h"
#endif

// ======================== وضعیت پارسر ========================
typedef enum {
    FRAME_STATE_IDLE = 0,
    FRAME_STATE_NMEA,
    FRAME_STATE_UBX_SYNC2,
    FRAME_STATE_UBX_CLASS,
    FRAME_STATE_UBX_ID,
    FRAME_STATE_UBX_LEN1,
    FRAME_STATE_UBX_LEN2,
    FRAME_STATE_UBX_PAYLOAD,
    FRAME_STATE_UBX_CK_A,
    FRAME_STATE_UBX_CK_B
} frame_state_t;

static frame_state_t g_state = FRAME_STATE_IDLE;
static uint8_t g_rx_buffer[GNSS_RX_BUFFER_SIZE];
static size_t  g_rx_index = 0;
static uint16_t g_ubx_length = 0;
static uint8_t  g_ubx_class = 0;
static uint8_t  g_ubx_id = 0;
static uint8_t  g_ubx_ck_a = 0;
static uint8_t  g_ubx_ck_b = 0;

// ======================== مقداردهی ========================
void gnss_frame_init(void)
{
    g_state = FRAME_STATE_IDLE;
    g_rx_index = 0;
}

// ======================== پردازش بایت ========================
gnss_error_t gnss_frame_feed_byte(uint8_t byte)
{
    gnss_error_t err = GNSS_OK;

    switch (g_state) {
        case FRAME_STATE_IDLE:
            if (byte == '$') {
                g_state = FRAME_STATE_NMEA;
                g_rx_index = 0;
                g_rx_buffer[g_rx_index++] = byte;
            } else if (byte == 0xB5) {
                g_state = FRAME_STATE_UBX_SYNC2;
                g_rx_index = 0;
                g_rx_buffer[g_rx_index++] = byte;
            }
            break;

        case FRAME_STATE_NMEA:
#if GNSS_ENABLE_NMEA
            g_rx_buffer[g_rx_index++] = byte;
            if (byte == '\n' || g_rx_index >= GNSS_RX_BUFFER_SIZE - 1) {
                err = nmea_parse(g_rx_buffer, g_rx_index);
                if (err != GNSS_OK) {
                    gnss_internal_report_error(err);
                }
                g_state = FRAME_STATE_IDLE;
                g_rx_index = 0;
            }
#else
            g_state = FRAME_STATE_IDLE;
#endif
            break;

        case FRAME_STATE_UBX_SYNC2:
            if (byte == 0x62) {
                g_state = FRAME_STATE_UBX_CLASS;
                g_rx_buffer[g_rx_index++] = byte;
            } else {
                g_state = FRAME_STATE_IDLE;
            }
            break;

        case FRAME_STATE_UBX_CLASS:
            g_ubx_class = byte;
            g_rx_buffer[g_rx_index++] = byte;
            g_state = FRAME_STATE_UBX_ID;
            break;

        case FRAME_STATE_UBX_ID:
            g_ubx_id = byte;
            g_rx_buffer[g_rx_index++] = byte;
            g_state = FRAME_STATE_UBX_LEN1;
            break;

        case FRAME_STATE_UBX_LEN1:
            g_ubx_length = byte;
            g_rx_buffer[g_rx_index++] = byte;
            g_state = FRAME_STATE_UBX_LEN2;
            break;

        case FRAME_STATE_UBX_LEN2:
            g_ubx_length |= ((uint16_t)byte << 8);
            g_rx_buffer[g_rx_index++] = byte;
            if (g_ubx_length > GNSS_RX_BUFFER_SIZE - 8) {
                g_state = FRAME_STATE_IDLE;
                return GNSS_ERR_BUFFER_OVERFLOW;
            }
            g_state = FRAME_STATE_UBX_PAYLOAD;
            g_rx_index = 6; // header already stored
            break;

        case FRAME_STATE_UBX_PAYLOAD:
            g_rx_buffer[g_rx_index++] = byte;
            if (g_rx_index - 6 >= g_ubx_length) {
                g_state = FRAME_STATE_UBX_CK_A;
            }
            break;

        case FRAME_STATE_UBX_CK_A:
            g_ubx_ck_a = byte;
            g_state = FRAME_STATE_UBX_CK_B;
            break;

        case FRAME_STATE_UBX_CK_B:
            g_ubx_ck_b = byte;
#if GNSS_ENABLE_UBX
            err = ubx_parse(g_rx_buffer, g_rx_index, g_ubx_ck_a, g_ubx_ck_b);
            if (err != GNSS_OK) {
                gnss_internal_report_error(err);
            }
#endif
            g_state = FRAME_STATE_IDLE;
            g_rx_index = 0;
            break;

        default:
            g_state = FRAME_STATE_IDLE;
            break;
    }

    if (g_rx_index >= GNSS_RX_BUFFER_SIZE) {
        g_state = FRAME_STATE_IDLE;
        g_rx_index = 0;
        return GNSS_ERR_BUFFER_OVERFLOW;
    }

    return err;
}

// ======================== پردازش بافر کامل ========================
gnss_error_t gnss_frame_parse_buffer(const uint8_t* buffer, size_t length)
{
    gnss_error_t last_err = GNSS_OK;
    for (size_t i = 0; i < length; i++) {
        gnss_error_t err = gnss_frame_feed_byte(buffer[i]);
        if (err != GNSS_OK && err != GNSS_ERR_UNSUPPORTED_MESSAGE) {
            last_err = err;
        }
    }
    return last_err;
}
