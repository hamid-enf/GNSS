// gnss/src/parser/ubx/ubx_parser.c
// پارسر UBX (ساده - فقط NAV-PVT پایه)

#include "ubx_parser.h"
#include "gnss_config.h"
#include "../core/gnss.h"
#include <string.h>

#if GNSS_ENABLE_UBX

gnss_error_t ubx_parse(const uint8_t* buffer, size_t length, uint8_t ck_a, uint8_t ck_b)
{
    // محاسبه checksum واقعی (Fletcher)
    uint8_t calc_a = 0, calc_b = 0;
    for (size_t i = 2; i < length - 2; i++) {
        calc_a += buffer[i];
        calc_b += calc_a;
    }

    if (calc_a != ck_a || calc_b != ck_b) {
        return GNSS_ERR_BAD_CHECKSUM;
    }

    uint8_t class_id = buffer[2];
    uint8_t msg_id   = buffer[3];
    uint16_t payload_len = buffer[4] | (buffer[5] << 8);

    // فقط NAV-PVT (Class 0x01, ID 0x07) را فعلاً پشتیبانی می‌کنیم
    if (class_id == 0x01 && msg_id == 0x07 && payload_len >= 92) {
        gnss_solution_t sol = {0};

        // iTOW (نادیده)
        // lon, lat, height
        int32_t lon = (int32_t)(buffer[10] | (buffer[11]<<8) | (buffer[12]<<16) | (buffer[13]<<24));
        int32_t lat = (int32_t)(buffer[14] | (buffer[15]<<8) | (buffer[16]<<16) | (buffer[17]<<24));
        int32_t hMSL = (int32_t)(buffer[22] | (buffer[23]<<8) | (buffer[24]<<16) | (buffer[25]<<24));

        sol.longitude_deg = lon / 10000000.0;
        sol.latitude_deg  = lat / 10000000.0;
        sol.altitude_m    = hMSL / 1000.0;

        // سرعت و جهت
        int32_t gSpeed = (int32_t)(buffer[66] | (buffer[67]<<8) | (buffer[68]<<16) | (buffer[69]<<24));
        int32_t headMot = (int32_t)(buffer[70] | (buffer[71]<<8) | (buffer[72]<<16) | (buffer[73]<<24));

        sol.speed_mps = gSpeed / 1000.0f;
        sol.course_deg = headMot / 100000.0f;

        // تعداد ماهواره و فیکس
        sol.satellites = buffer[23 + 8]; // numSV
        uint8_t fixType = buffer[20];
        sol.fix_type = fixType;
        sol.valid_position = (fixType >= 2);

        gnss_internal_update_solution(&sol);
        return GNSS_OK;
    }

    return GNSS_ERR_UNSUPPORTED_MESSAGE;
}

#endif // GNSS_ENABLE_UBX
