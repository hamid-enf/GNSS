// gnss/include/gnss_config.h
#ifndef GNSS_CONFIG_H
#define GNSS_CONFIG_H

// ======================== سطح فعال‌سازی پروتکل‌ها ========================
#define GNSS_ENABLE_NMEA          1
#define GNSS_ENABLE_UBX           1
#define GNSS_ENABLE_VENDOR_EXT    0

// ======================== پیام‌های NMEA ========================
#define GNSS_ENABLE_GGA           1
#define GNSS_ENABLE_RMC           1
#define GNSS_ENABLE_GSA           1
#define GNSS_ENABLE_GSV           1
#define GNSS_ENABLE_VTG           1
#define GNSS_ENABLE_GLL           0
#define GNSS_ENABLE_ZDA           0

// ======================== تنظیمات حافظه ========================
#define GNSS_MAX_SATELLITES       32
#define GNSS_RX_BUFFER_SIZE       128

// ======================== دقت عددی ========================
#define GNSS_USE_DOUBLE           1
#define GNSS_USE_FLOAT            0

// ======================== قابلیت‌های اضافی ========================
#define GNSS_ENABLE_CALLBACKS     1
#define GNSS_ENABLE_STATS         1
#define GNSS_ENABLE_STRING_API    0
#define GNSS_ENABLE_RAW_MESSAGES  0

// ======================== اندازه‌گیری عملکرد ========================
#define GNSS_ENABLE_BENCHMARK     0

#endif // GNSS_CONFIG_H
